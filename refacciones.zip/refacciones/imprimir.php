<?php
require_once('/vendor/autoload.php');
 require_once('conexion.php');
$mpdf = new \Mpdf\Mpdf([

]);

$css = file_get_contents('plantilla/reporte/style.css');
    $expediente=$_POST['expediente'];
    $idcliente=$_POST['idcliente'];
     $detalle=$_POST['detalle'];

      $clavebuscadah=mysql_query("SELECT nombre,telefono FROM tblcliente WHERE idcliente=$idcliente") or die("Problemas en el select:".mysql_error());
            while($row = mysql_fetch_array($clavebuscadah))
        {
          $nombre=$row['nombre'];
          $telefono=$row['telefono'];
        }


           $clavebuscadah9=mysql_query("SELECT sum(subtotal) total FROM tblcotizacion WHERE detallecotizacion=$detalle and idcliente=$idcliente ") or die("Problemas en el select:".mysql_error());
            while($row9 = mysql_fetch_array($clavebuscadah9))
        {
          $total=$row9['total'];
        }


$consulta=mysql_query("SELECT pi.descripcion,co.cantidad,pi.precio,co.subtotal FROM tblcotizacion  as co inner join tblpiezas as pi on (co.idpiesa=pi.idpiesa) where co.detallecotizacion=$detalle and co.idcliente=$idcliente",$conexion) or die (mysql_error());

$hoy = date("Y-m-d H:i:s"); 
$html ='';
$html .='  

<table>
<tr>
<td align="left"> <img src="images/logo.jpg"> </td>
<td class="encabezado"> Telefono: 56 88 00 72 - 56 88 06 57 <br> Sucursal:  Carrillo Puerto # 302 Col. General Anaya <br> Fecha: '. $hoy.'  </td>
</tr>
</table>

<H1>Cotización</H1>

  ';

$html .='<p>Cliente: '.$nombre.'</p> <p>Telefono: '.$telefono.'</p><p> Numero de expediente :'.$expediente.'</p>' ;

// Mostrar resultados de la consulta
  $nfilas = mysql_num_rows ($consulta);

  if ($nfilas > 0)
  {
     $html .='<TABLE>\n';
     $html .='<TR>\n';
     $html .='<TH>Descripcion</TH>\n';
     $html .='<TH>Cantidad</TH>\n';
     $html .='<TH>Precio</TH>\n';
     $html .='<TH>Subtotal</TH>\n';
     $html .='</TR>\n';

     for ($i=0; $i<$nfilas; $i++)
     {
        $resultado = mysql_fetch_array ($consulta);
        $html .='<TR>\n';

        $html .='<TD>' . $resultado['descripcion'] . '</TD>\n';
        $html .='<TD>' . $resultado['cantidad'] . '</TD>\n';
        $html .='<TD>' . $resultado['precio'] . '</TD>\n';
        $html .='<TD>' . $resultado['subtotal'] . '</TD>\n';
        $html .='</TR>\n';
      
      }
       $html .='<TR>\n';
        $html .='<TD>' . '</TD>\n';
         $html .='<TD>'  . '</TD>\n';
         $html .='<TD>' .'Total :'.'</TD>\n';
         $html .='<TD>' .$total. '</TD>\n';
         $html .='</TR>\n';

     $html .='</TABLE>';

  }
  else
     print ("No hay datos disponibles");

;


$mpdf->writeHtml($css,\Mpdf\HTMLParserMode::HEADER_CSS);
$mpdf->writeHtml($html,\Mpdf\HTMLParserMode::HTML_BODY);
$mpdf->Output();
?>