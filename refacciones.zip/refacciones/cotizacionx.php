<!DOCTYPE html>

<html>
<head>
<title>Yosemite Automotriz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 

    <style>@charset "utf-8";
/* CSS Document */


.seleccionar
{background-image: url(images/demo/seleccionar.jpg); width: 22px; height: 27px; border-width: 0}
.imprimir
{background-image: url(images/demo/imprimir.jpg); width: 71px; height: 57px; border-width: 0}


table td {
    background-color: black;
}

.login {
  border: none;
  width: 50px;
  height: 30px;
  padding-left: 3px;
  border: 1px solid #000;
  background-color: #dedede;
  background: -webkit-linear-gradient(top, #c3c3c3 0%, #eaeaea 100%); 
  color: #363636;
  text-shadow: 0 1px 0 #fff;
  outline: none;
      text-transform: uppercase ;
  border-bottom: none;
  -webkit-border-radius: 5px 5px 0 0;
  -moz-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;
  -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, .4);
}
</style>


  

<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">


</head>


<body id="top">
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.jpg');"> 
 <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="index.php">Yosemite Automotriz</a></h1>
      </div>

      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li class="active"><a href="index.php">Inicio</a></li>
           <li><a class="drop" href="#">Productos</a>
            <ul>
              <li><a href="guardarproductos.php">Guardar</a></li>
              <li><a href="consultarproductos.php">Consultar</a></li>

            </ul>
          </li>
          <li><a class="drop" href="#">Proveedores</a>
            <ul>
              <li><a href="guardarproveedor.php">Guardar</a></li>
            </ul>
          </li>
      
          <li><a href="cotizaciones.php">Cotizaciones</a></li>
        </ul>
      </nav>
    </header>
  </div>
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="flexslider basicslider">

                <div class="single-features">
           

              




<?PHP

if( isset($_POST["Seleccionar"]) ){
     require_once('conexion.php');
    $idve=$_POST['idve'];
$Telefono=$_POST['Telefono'];
  $cantidad=$_POST['cantidad'];
  $idpiesa=$_POST['idpiesa'];
  $precio=$_POST['precio'];
  $expediente=$_POST['expediente'];
  $descripcion=$_POST['descripcion'];
     $origen_nueva_o_usada=$_POST['origen_nueva_o_usada'];
     $cantidad_existencia=$_POST['cantidad_existencia'];

     if ($cantidad > $cantidad_existencia){
        echo "La cantidad requerida excede el limite de existencias";
     }else{

        $subtotal=$precio*$cantidad;

        $clavebuscadah=mysql_query("SELECT idcliente,nombre FROM tblcliente WHERE telefono='$Telefono'") or die("Problemas en el select:".mysql_error());
            while($row = mysql_fetch_array($clavebuscadah))
        {
          $idcliente=$row['idcliente'];
          $nombre=$row['nombre'];
        }

        $clavebuscadah1=mysql_query("SELECT max(idtiket) detalle FROM tbltiket") or die("Problemas en el select:".mysql_error());
            while($row1 = mysql_fetch_array($clavebuscadah1))
        {
          $detalle=$row1['detalle'];
        }

  $instruccion= "INSERT INTO tblcotizacion (idcliente,detallecotizacion,idpiesa,cantidad,subtotal,expediente) values($idcliente,$detalle,$idpiesa,$cantidad,$subtotal,'$expediente')";
   $consulta = mysql_query ($instruccion)
   or die ("<p> hubo un problema</p>" );
  echo "<p>Se Guardo con exito.</p>";


   $clavebuscadah9=mysql_query("SELECT sum(subtotal) total FROM tblcotizacion WHERE detallecotizacion=$detalle and idcliente=$idcliente ") or die("Problemas en el select:".mysql_error());
            while($row9 = mysql_fetch_array($clavebuscadah9))
        {
          $total=$row9['total'];
        }


$consulta=mysql_query("SELECT pi.descripcion,co.cantidad,pi.precio,co.subtotal FROM tblcotizacion  as co inner join tblpiezas as pi on (co.idpiesa=pi.idpiesa) where co.detallecotizacion=$detalle and co.idcliente=$idcliente",$conexion) or die (mysql_error());


echo "<p>Cliente: ".$nombre."</p>";
echo "<p>Telefono: ".$Telefono."</p>";
echo " <p> Numero de expediente :".$expediente."</p>";


// Mostrar resultados de la consulta
  $nfilas = mysql_num_rows ($consulta);
  if ($nfilas > 0)
  {
     print ("<TABLE>\n");
     print ("<TR>\n");
     print ("<TH>Descripcion</TH>\n");
      print ("<TH>Cantidad</TH>\n");
     print ("<TH>Precio</TH>\n");
      print ("<TH>Subtotal</TH>\n");
     print ("</TR>\n");

     for ($i=0; $i<$nfilas; $i++)
     {
        $resultado = mysql_fetch_array ($consulta);
        print ("<TR>\n");
        print ("<TD>" . $resultado['descripcion'] . "</TD>\n");
        print ("<TD>" . $resultado['cantidad'] . "</TD>\n");
        print ("<TD>" . $resultado['precio'] . "</TD>\n");
        print ("<TD>" . $resultado['subtotal'] . "</TD>\n");
        print ("</TR>\n");
      
      }
       print ("<TR>\n");
        print ("<TD>" . "</TD>\n");
        print ("<TD>" . "</TD>\n");
        print ("<TD>" ."Total :"."</TD>\n");
        print ("<TD>" .$total. "</TD>\n");
        print ("</TR>\n");

     print ("</TABLE>\n");

  }
  else
     print ("No hay datos disponibles");

   $imp= "
        <form action='"."imprimir.php'"." method="."'post'".">"."<input type="."'hidden'"."name="."'expediente'". "value='". $expediente . "'/>"."<input type="."'hidden'"."name="."'idcliente'". "value='". $idcliente . "'/>"."<input type="."'hidden'"."name="."'detalle'". "value='". $detalle . "'/>"."<input name=".'"'."impri".'"'. "type=".'"'.'submit'.'"'."class=".'"'.'imprimir'.'"'."value=".'"'. '"'. ">"." </form>";
        print $imp;
  


     }

  }


  ?>

     <?PHP
 require_once('conexion.php');
   
                      
    if( isset($_POST["cotizar"]) ){
        $Telefono=$_POST['Telefono'];
        $nombre=$_POST['nombre'];
        $expediente=$_POST['expediente'];
        


        $clavebuscadah=mysql_query("SELECT count(*) num FROM tblcliente WHERE telefono='$Telefono' and nombre = '$nombre'") or die("Problemas en el select:".mysql_error());
            while($row = mysql_fetch_array($clavebuscadah))
        {
          $num=$row['num'];
        }
        if($num == 0){
            $instruccion= "INSERT INTO  tblcliente (nombre,telefono) values('$nombre','$Telefono')";
           $consulta = mysql_query ($instruccion)
           or die ("<p> hubo un problema</p>" );
        }


                          $marca=$_POST['marca'];
                          $modelo=$_POST['modelo'];
                          $anio=$_POST['anio'];
                          $tipo=$_POST['tipo'];

          $clavebuscadah=mysql_query("SELECT ve.idvehiculo,ma.nombre MARCA,mo.nombre MODELO,ve.Anio from tblvehiculo as ve inner join tblmarca as ma on(ve.idmarca=ma.idmarca) inner join tblmodelo as mo on(ve.idmodelo=mo.idmodelo) WHERE ve.idmarca=$marca and ve.idmodelo=$modelo and ve.Anio=$anio") or
                                die("Problemas en el select:".mysql_error());


                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                $idve=$row['idvehiculo'];
                                 $MARCA=$row['MARCA'];
                                  $MODELO=$row['MODELO'];
                                }

                    echo "<p> Auto a cotizar:</p> <br> <center><p>".$MARCA." ".$MODELO." ".$anio."</p></center>";
                      

}
                          



                          ?>

  
<?PHP

        
          $Telefono=$_POST['Telefono'];
          
          $tipo=$_POST['tipo'];
     mysql_query("SET NAMES 'utf8'");           

$consulta=mysql_query("SELECT pi.idpiesa,P.nombre proveedor,P.telefono,pi.descripcion,pi.cantidad_existencia,pi.origen_nueva_o_usada,pi.precio,ti.nombre tipo from tblpiezas as pi inner join tblproveedores as P on(pi.idproveedor=P.idproveedor) inner join tbltipo as ti on (pi.tipo=ti.idtipo) where pi.idvehiculo=$idve and pi.tipo=$tipo",$conexion) or die (mysql_error());

// Mostrar resultados de la consulta
  $nfilas = mysql_num_rows ($consulta);
  if ($nfilas > 0)
  {
     print ("<TABLE>\n");
     print ("<TR>\n");
     print ("<TH>Proveedor</TH>\n");
      print ("<TH>Telefono</TH>\n");
     print ("<TH>Descripcion</TH>\n");
      print ("<TH>Existencia</TH>\n");
      print ("<TH>Origen</TH>\n");
      print ("<TH>Precio</TH>\n");
      print ("<TH>Tipo</TH>\n");
    print ("<TH>Cantidad</TH>\n");
     print ("</TR>\n");

     for ($i=0; $i<$nfilas; $i++)
     {
        $resultado = mysql_fetch_array ($consulta);
        print ("<TR>\n");
        print ("<TD>" . $resultado['proveedor'] . "</TD>\n");
        print ("<TD>" . $resultado['telefono'] . "</TD>\n");
        print ("<TD>" . $resultado['descripcion'] . "</TD>\n");
        print ("<TD>" . $resultado['cantidad_existencia'] . "</TD>\n");
        print ("<TD>" . $resultado['origen_nueva_o_usada'] . "</TD>\n");
        print ("<TD>" . $resultado['precio'] . "</TD>\n");
        print ("<TD>" . $resultado['tipo'] . "</TD>\n");
        $selec= "
        <form action='"."cotizacionx.php'"." method="."'post'".">". "<table><tr><td>  <input type="."'text'"."name="."'cantidad'"."class="."'login'". "> </td>"."<td><input type="."'hidden'"."name="."'idpiesa'". "value='". $resultado['idpiesa'] . "'/>". "<input type="."'hidden'"."name="."'cantidad_existencia'". "value='". $resultado['cantidad_existencia'] . "'/>"."<input type="."'hidden'"."name="."'Telefono'". "value='". $Telefono . "'/>"."<input type="."'hidden'"."name="."'expediente'". "value='". $expediente . "'/>"."<input type="."'hidden'"."name="."'idve'". "value='". $idve . "'/>"."<input type="."'hidden'"."name="."'tipo'". "value='". $tipo . "'/>"."<input type="."'hidden'"."name="."'descripcion'". "value='". $resultado['descripcion'] . "'/>"."<input type="."'hidden'"."name="."'origen_nueva_o_usada'". "value='". $resultado['origen_nueva_o_usada'] . "'/>"."<input type="."'hidden'"."name="."'precio'". "value='". $resultado['precio'] . "'/>"."<input name=".'"'."Seleccionar".'"'. "type=".'"'.'submit'.'"'."class=".'"'.'seleccionar'.'"'."value=".'"'. '"'. ">"."</td><tr></table> </form>";
        print ("<TD>" .$selec. "</TD>\n");
      }
     print ("</TABLE>\n");
  }
  else
     print ("No hay datos disponibles");


?>       





</div>

    </div>
    <!-- ################################################################################################ -->
  </div>
  <!-- ################################################################################################ -->
</div>





<div class="wrapper row4 bgded overlay" style="background-image:url('images/demo/backgrounds/02.png');">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h3 class="heading">Yosemite Automotriz</h3>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
      </ul>
    </div>
    <div class="one_third">
      <ul class="nospace meta">
        <li class="btmspace-15"><i class="fa fa-phone"></i>   55-6752-7532 Ext.1248</li>
        <li><i class="fa fa-envelope-o"></i> contacto@YosemiteAutomotriz.com</li>
      </ul>
    </div>
    <div class="one_third">
      <form method="post" action="#">
        <fieldset>
       
        </fieldset>
      </form>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right"> <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates"></a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>



          <script>
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
     <script>
function solonumeros(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }


    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
    <script>
function solonumerosyletras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789áéíóúabcdefghijklmnñopqrstuvwxyz,:;¿?#()";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>  



<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>