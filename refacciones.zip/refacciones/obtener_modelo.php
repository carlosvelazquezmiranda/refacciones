

<?php
require_once('conexion.php'); 

$marca = $_REQUEST['q'];
//$criador = mysqli_real_escape_string($con, $_POST["criador"]);

$clavebuscadah=mysql_query("Select idmodelo,nombre  from tblmodelo where idmarca=$marca ") or die("Problemas en el select:".mysql_error());
//while($row = mysql_fetch_array($clavebuscadah))
//{
//echo'<OPTION VALUE="'.utf8_decode($row['raza']).'">'.utf8_decode($row['raza']).'</OPTION>';
//}

?>
<select id="modelo" name ="modelo">

<?php while($fila=mysql_fetch_array($clavebuscadah)){ ?>
<option value="<?php echo $fila['idmodelo']; ?>"><?php echo $fila['nombre']; ?></option>
<?php } ?>

</select>
