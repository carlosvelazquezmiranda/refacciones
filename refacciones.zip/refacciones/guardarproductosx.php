<!DOCTYPE html>

<html>
<head>
<title>Yosemite Automotriz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 

    <style>@charset "utf-8";
/* CSS Document */

/* ---------- FONTAWESOME ---------- */
/* ---------- http://fortawesome.github.com/Font-Awesome/ ---------- */
/* ---------- http://weloveiconfonts.com/ ---------- */

@import url(http://weloveiconfonts.com/api/?family=fontawesome);

/* ---------- ERIC MEYER'S RESET CSS ---------- */
/* ---------- http://meyerweb.com/eric/tools/css/reset/ ---------- */

@import url(http://meyerweb.com/eric/tools/css/reset/reset.css);

/* ---------- FONTAWESOME ---------- */

/* [class*="fontawesome-"]:before {
  font-family: 'FontAwesome', sans-serif;
} */
/* general */


.eliminar
{background-image: url(images/demo/eliminar.jpg); width: 29px; height: 29px; border-width: 0}

.actualizar
{background-image: url(images/demo/editar.jpg); width: 20px; height: 18px; border-width: 0}

input {
  font-size: 1em;
  line-height: 1.5em;
  margin: 3px;
  padding: 3px;
  -webkit-appearance: none;
  appearance: none;
}

/* login */
#login {
  width: 500px;
  margin: 1px auto;
  
}
#login label {
  position: absolute;
  display: block;
  width: 36px;
  height: 48px;
  line-height: 48px;
  text-align: center;
  font-family: 'FontAwesome', sans-serif;
  color: #676767;
  text-shadow: 0 1px 0 #fff;
}
#login input,select {
  border: none;
  width: 500px;
  height: 48px;
  padding-left: 36px;
  border: 1px solid #000;
  background-color: #dedede;
  background: -webkit-linear-gradient(top, #c3c3c3 0%, #eaeaea 100%); 
  color: #363636;
  text-shadow: 0 1px 0 #fff;
  outline: none;
}
#login input[type="text"] {
    text-transform: uppercase ;
  border-bottom: none;
  -webkit-border-radius: 5px 5px 0 0;
  -moz-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;
  -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, .4);
}
#login input[type="password"] {
  border-top:none;
  -webkit-border-radius: 0 0 5px 5px;
  -moz-border-radius: 0 0 5px 5px;
  border-radius: 0 0 5px 5px;
  margin-bottom: 20px;
  -webkit-box-shadow:inset 0 1px 0 rgba(255, 255, 255, .3), 0 1px 1px rgba(0, 0, 0, .2);
}
#login input[type="select"] {
  border-bottom: none;
  -webkit-border-radius: 5px 5px 0 0;
  -moz-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;
  -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, .4);
}
#login input[type="submit"] {
  
    background-image:url('images/demo/aceptar1.png');
background-repeat:no-repeat;
background-size: 6em;
  height: 85px;
  width: 85px;
  display: table;
  margin: 20px auto;
  border-radius: 100%;
  cursor: pointer;
    box-shadow: inset 0 10px 15px rgba(255,255,255,.35), inset 0 -10px 15px rgba(0,0,0,.05), inset 10px 0 15px rgba(0,0,0,.05), inset -10px 0 15px rgba(0,0,0,.05), 0 5px 20px rgba(0,0,0,.1);
    
        }
#login input[type="submit"]:hover {
  box-shadow: inset 0 5px 30px rgba(0,0,0,.2);
  background-size: 5.9em;
        }
    
             
</style>

 <link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
    <script type="text/javascript" src="tablecloth/tablecloth.js"></script>


<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">

</head>


<body id="top">
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.jpg');"> 
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="index.php">Yosemite Automotriz</a></h1>
      </div>

      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li class="active"><a href="index.php">Inicio</a></li>
           <li><a class="drop" href="#">Productos</a>
            <ul>
              <li><a href="guardarproductos.php">Guardar</a></li>
              <li><a href="consultarproductos.php">Consultar</a></li>

            </ul>
          </li>
          <li><a class="drop" href="#">Proveedores</a>
            <ul>
              <li><a href="guardarproveedor.php">Guardar</a></li>
            </ul>
          </li>
      
          <li><a href="cotizaciones.php">Cotizaciones</a></li>
        </ul>
      </nav>
    </header>
  </div>
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="flexslider basicslider">

                <div class="single-features">
             <div class="password-container" id="login">

                  <?PHP

                        require_once('conexion.php');
                        if( isset($_POST["guardar_vehiculo"]) ){
                          $marca=$_POST['marca'];
                          $modelo=$_POST['modelo'];
                          $anio=$_POST['anio'];
                          
                            
                                $clavebuscadah=mysql_query("SELECT ve.idvehiculo,ma.nombre MARCA,mo.nombre MODELO,ve.Anio from tblvehiculo as ve inner join tblmarca as ma on(ve.idmarca=ma.idmarca) inner join tblmodelo as mo on(ve.idmodelo=mo.idmodelo) WHERE ve.idmarca=$marca and ve.idmodelo=$modelo and ve.Anio=$anio") or
                                die("Problemas en el select:".mysql_error());


                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                $idve=$row['idvehiculo'];
                                 $MARCA=$row['MARCA'];
                                  $MODELO=$row['MODELO'];
                                }

                    echo "<p>Alta de piezas en el Almacen para su venta de un Auto:</p> <br> <center><p>".$MARCA." ".$MODELO." ".$anio."</p></center>";
                      


                          }



                          ?>
     
      <form action="guardarproductos.php" method="POST">
           
             <input type="hidden"  name="idvehiculo" value="<?php  echo  $idve; ?>" />
                 <p>A que grupo pertenece la pieza</p>
                          <SELECT  id="tipo" onchange="load(this.value)" required NAME="tipo" >
                                <option value=" "> </option>
                                <?php 
                                require_once('conexion.php'); 
                                mysql_query ("SET NAMES 'utf8'");
                                $clavebuscadah=mysql_query("SELECT idtipo, nombre FROM tbltipo") or
                                die("Problemas en el select:".mysql_error());
                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                echo'<OPTION VALUE="'.utf8_decode($row['idtipo']).'">'.utf8_decode($row['nombre']).'</OPTION>';
                                }

                                ?>
                  </SELECT> 

            <p>Proveedor</p>
          <SELECT  id="idproveedor" onchange="load(this.value)" required NAME="idproveedor" >
                                <option value=" "> </option>
                                <?php 
                                require_once('conexion.php'); 
                                mysql_query ("SET NAMES 'utf8'");
                                $clavebuscadah=mysql_query("SELECT idproveedor, nombre FROM tblproveedores") or
                                die("Problemas en el select:".mysql_error());
                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                echo'<OPTION VALUE="'.utf8_decode($row['idproveedor']).'">'.utf8_decode($row['nombre']).'</OPTION>';
                                }

                                ?>
                  </SELECT>  

                      <p>Descripción</p>
                      <input required type="text"   placeholder="Descripcion de la pieza" name="descripcion" onkeypress="return solonumerosyletras(event)" onblur="limpia()" pattern="[a-z 0-9A-ZñÑáéíóúÁÉÍÓÚüÜ.]+"/>
                      <p>Cantidad a solicitar</p>
                      <input required type="number"   name="cantidad_existencia" onkeypress="return solonumeros(event)" onblur="limpia()"/>
                      <p>Origen</p>
                       <select name="origen_nueva_o_usada">
                          <option value="Nueva">Nueva</option>
                          <option value="Usada">Usada</option>
                       </select>
                       <p>Precio</p>
                       <input required type="number"   name="precio" onkeypress="return solonumeros(event)" onblur="limpia()"/>
                   



                  
                      <input value="" type="submit" name="guardar_pieza"></p>

                  
      </form>
                      





  </div>
</div>

    </div>
    <!-- ################################################################################################ -->
  </div>
  <!-- ################################################################################################ -->
</div>




<div class="wrapper row4 bgded overlay" style="background-image:url('images/demo/backgrounds/02.png');">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h3 class="heading">Yosemite Automotriz</h3>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
      </ul>
    </div>
    <div class="one_third">
      <ul class="nospace meta">
        <li class="btmspace-15"><i class="fa fa-phone"></i>   55-6752-7532 Ext.1248</li>
        <li><i class="fa fa-envelope-o"></i> contacto@YosemiteAutomotriz.com</li>
      </ul>
    </div>
    <div class="one_third">
      <form method="post" action="#">
        <fieldset>
       
        </fieldset>
      </form>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right"> <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates"></a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>



          <script>
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
     <script>
function solonumeros(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }


    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
    <script>
function solonumerosyletras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789áéíóúabcdefghijklmnñopqrstuvwxyz,:;¿?#()";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>  



<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>