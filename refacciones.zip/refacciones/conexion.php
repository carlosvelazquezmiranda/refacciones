<?php  
#require_once('file:///C|/Users/Charly/Downloads/public_html/config.php');

#  Check database to host connection 
if(!function_exists('mysql_connect'))
{
    echo 'PHP cannot find the mysql extension. MySQL is required for run. Aborting.';
    exit();
}


$conexion = @mysql_connect('localhost','root','')
or die('No se puede conectar con el servidor'.mysql_error());

mysql_select_db('bdrefacciones', $conexion)
or die('No se puede seleccionar la base de datos'.mysql_error());


/*
$conexion = @mysql_connect('localhost','root','')
or die('No se puede conectar con el servidor'.mysql_error());

mysql_select_db('winweb', $conexion)
or die('No se puede seleccionar la base de datos'.mysql_error());
*/
?> 