<!DOCTYPE html>

<html>
<head>
<title>Yosemite Automotriz</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 

    <style>@charset "utf-8";
/* CSS Document */

/* ---------- FONTAWESOME ---------- */
/* ---------- http://fortawesome.github.com/Font-Awesome/ ---------- */
/* ---------- http://weloveiconfonts.com/ ---------- */

@import url(http://weloveiconfonts.com/api/?family=fontawesome);

/* ---------- ERIC MEYER'S RESET CSS ---------- */
/* ---------- http://meyerweb.com/eric/tools/css/reset/ ---------- */

@import url(http://meyerweb.com/eric/tools/css/reset/reset.css);

/* ---------- FONTAWESOME ---------- */

/* [class*="fontawesome-"]:before {
  font-family: 'FontAwesome', sans-serif;
} */
/* general */


.eliminar
{background-image: url(images/demo/eliminar.png); width: 21px; height: 21px; border-width: 0}

.actualizar
{background-image: url(images/demo/editar.jpg); width: 20px; height: 18px; border-width: 0}

input {
  font-size: 1em;
  line-height: 1.5em;
  margin: 3px;
  padding: 3px;
  -webkit-appearance: none;
  appearance: none;
}

/* login */
#login {
  width: 500px;
  margin: 1px auto;
  
}
#login label {
  position: absolute;
  display: block;
  width: 36px;
  height: 48px;
  line-height: 48px;
  text-align: center;
  font-family: 'FontAwesome', sans-serif;
  color: #676767;
  text-shadow: 0 1px 0 #fff;
}
#login input,select {
  border: none;
  width: 500px;
  height: 48px;
  padding-left: 36px;
  border: 1px solid #000;
  background-color: #dedede;
  background: -webkit-linear-gradient(top, #c3c3c3 0%, #eaeaea 100%); 
  color: #363636;
  text-shadow: 0 1px 0 #fff;
  outline: none;
}
#login input[type="text"] {
    text-transform: uppercase ;
  border-bottom: none;
  -webkit-border-radius: 5px 5px 0 0;
  -moz-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;
  -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, .4);
}
#login input[type="password"] {
  border-top:none;
  -webkit-border-radius: 0 0 5px 5px;
  -moz-border-radius: 0 0 5px 5px;
  border-radius: 0 0 5px 5px;
  margin-bottom: 20px;
  -webkit-box-shadow:inset 0 1px 0 rgba(255, 255, 255, .3), 0 1px 1px rgba(0, 0, 0, .2);
}
#login input[type="select"] {
  border-bottom: none;
  -webkit-border-radius: 5px 5px 0 0;
  -moz-border-radius: 5px 5px 0 0;
  border-radius: 5px 5px 0 0;
  -webkit-box-shadow:inset 0 -1px 0 rgba(0, 0, 0, .4);
}
#login input[type="submit"] {
  
    background-image:url('images/demo/aceptar1.png');
background-repeat:no-repeat;
background-size: 6em;
  height: 85px;
  width: 85px;
  display: table;
  margin: 20px auto;
  border-radius: 100%;
  cursor: pointer;
    box-shadow: inset 0 10px 15px rgba(255,255,255,.35), inset 0 -10px 15px rgba(0,0,0,.05), inset 10px 0 15px rgba(0,0,0,.05), inset -10px 0 15px rgba(0,0,0,.05), 0 5px 20px rgba(0,0,0,.1);
    
        }
#login input[type="submit"]:hover {
  box-shadow: inset 0 5px 30px rgba(0,0,0,.2);
  background-size: 5.9em;
        }
    table td {
    background-color: black;
}
             
</style>



  

<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">

</head>


<body id="top">
<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.jpg');"> 
  <div class="wrapper row1">
    <header id="header" class="hoc clear"> 
      <!-- ################################################################################################ -->
      <div id="logo" class="fl_left">
        <h1><a href="index.php">Yosemite Automotriz</a></h1>
      </div>

      <nav id="mainav" class="fl_right">
        <ul class="clear">
          <li class="active"><a href="index.php">Inicio</a></li>
           <li><a class="drop" href="#">Productos</a>
            <ul>
              <li><a href="guardarproductos.php">Guardar</a></li>
              <li><a href="consultarproductos.php">Consultar</a></li>

            </ul>
          </li>
          <li><a class="drop" href="#">Proveedores</a>
            <ul>
              <li><a href="guardarproveedor.php">Guardar</a></li>
            </ul>
          </li>
      
          <li><a href="cotizaciones.php">Cotizaciones</a></li>
        </ul>
      </nav>
    </header>
  </div>
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="flexslider basicslider">

                <div class="single-features">
             <div class="password-container" id="login">
                 <?PHP
                 require_once('conexion.php');
                   if( isset($_POST["guardar_proveedor"]) ){
                         require_once('conexion.php');
                          $nombre=$_POST['nombre'];
                          $telefono=$_POST['telefono'];
                          $email=$_POST['email'];

                           $clavebuscadah=mysql_query("SELECT count(*) existe FROM tblproveedores WHERE telefono=$telefono ") or
                                die("Problemas en el select:".mysql_error());


                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                $existe=$row['existe'];
                                }
                                if($existe == 0){

                            $instruccion= "INSERT INTO tblproveedores(nombre,telefono,correo) VALUES 
                           ('$nombre','$telefono','$email')";
                           
                           $consulta = mysql_query ($instruccion)
                           or die ("<p> hubo un problema</p>" );
                                   echo "<br><center><p>Se ha registrado con exito el proveedor.</p></center><br>";

                                }

                      }
                      

                    
                ?>
                <?PHP

if( isset($_POST["Eliminar"]) ){
  $idproveedor=$_POST['idproveedor'];

  $instruccion= "DELETE FROM tblproveedores where idproveedor=$idproveedor";
   $consulta = mysql_query ($instruccion)
   or die ("<p> hubo un problema</p>" );
  echo "<p>Se elimino con exito el registro.</p>";
  }




  ?>
     
      <form action="guardarproveedor.php" method="POST">
  <?PHP 
             if( isset($_POST["Actualizar"]) ){
               $idproveedor=$_POST['idproveedor'];

                       $clavebuscadah=mysql_query("SELECT nombre,telefono,correo FROM tblproveedores WHERE idproveedor=$idproveedor ") or
                                die("Problemas en el select:".mysql_error());


                                while($row = mysql_fetch_array($clavebuscadah))
                                {
                                $nombre=$row['nombre'];
                                $telefono=$row['telefono'];
                                $email=$row['correo'];
                                }

            }else{
                $idproveedor="";
                $nombre="";
                $telefono="";
                $email="";
            }



              if( isset($_POST["Modificar"]) ){
  $idproveedor=$_POST['idproveedor'];
   $nombre=$_POST['nombre'];
$telefono=$_POST['telefono'];
 $email=$_POST['email'];


  $instruccion= "UPDATE tblproveedores SET nombre='$nombre', telefono='$telefono' , correo='$email' where idproveedor=$idproveedor";
   $consulta = mysql_query ($instruccion)
   or die ("<p> hubo un problema</p>" );
  echo "<p>Se actualizo con exito el registro.</p>";
  }


?>
 <input required type="hidden"    name="idproveedor" value="<?php echo $idproveedor; ?>"/>

            <p>Nombre</p>
            <input required type="text"   placeholder="Nombre Proveedor" name="nombre" onkeypress="return solonumerosyletras(event)" onblur="limpia()" pattern="[a-z 0-9A-ZñÑáéíóúÁÉÍÓÚüÜ.]+" value="<?php echo $nombre; ?>"/>
            <p>Telefono</p>
             <input required type="text"   placeholder="Telefono Proveedor" name="telefono" onkeypress="return solonumeros(event)" onblur="limpia()" pattern="[a-z 0-9A-ZñÑáéíóúÁÉÍÓÚüÜ.]+" value="<?php echo $telefono; ?>"/>
              <p>Correo</p>
             <input required type="email"   placeholder="Correo electronico" name="email" value="<?php echo $email; ?>" />
        <?PHP
             
             if( isset($_POST["Actualizar"]) ){

                $actu=' 
                    <input value="" type="submit" name="Modificar"></p>
                 ';
             }else{

                 $actu=' 
                    <input value="" type="submit" name="guardar_proveedor"></p>
                 ';
             }

             echo $actu;

            ?>


                
      </form>


  </div>
</div>


<?PHP

     mysql_query("SET NAMES 'utf8'");           

$consulta=mysql_query("select idproveedor,nombre,telefono,correo from tblproveedores",$conexion) or die (mysql_error());

// Mostrar resultados de la consulta
  $nfilas = mysql_num_rows ($consulta);
  if ($nfilas > 0)
  {
     print ("<TABLE>\n");
     print ("<TR>\n");
     print ("<TH>Nombre</TH>\n");
      print ("<TH>Telefono</TH>\n");
     print ("<TH>Correo</TH>\n");
      print ("<TH>Eliminar</TH>\n");
      print ("<TH>Actualizar</TH>\n");
     print ("</TR>\n");

     for ($i=0; $i<$nfilas; $i++)
     {
        $resultado = mysql_fetch_array ($consulta);

        
        print ("<TR>\n");
        print ("<TD>" . $resultado['nombre'] . "</TD>\n");
        print ("<TD>" . $resultado['telefono'] . "</TD>\n");
        print ("<TD>" . $resultado['correo'] . "</TD>\n");

        $elim= "<form action='"."guardarproveedor.php'"." method="."'post'".">". "<input type="."'hidden'"."name="."'idproveedor'". "value='". $resultado['idproveedor'] . "'/>"."<input name=".'"'."Eliminar".'"'. "type=".'"'.'submit'.'"'."class=".'"'.'eliminar'.'"'."value=".'"'. '"'. ">"."</form>";
             print ("<TD>" .$elim. "</TD>\n");

        $actualizar= "<form action='"."guardarproveedor.php'"." method="."'post'".">". "<input type="."'hidden'"."name="."'idproveedor'". "value='". $resultado['idproveedor'] . "'/>"."<input name=".'"'."Actualizar".'"'. "type=".'"'.'submit'.'"'."class=".'"'.'actualizar'.'"'."value=".'"'. '"'. ">"."</form>";
             print ("<TD>" .$actualizar. "</TD>\n");
      }
     print ("</TABLE>\n");
  }
  else
     print ("No hay datos disponibles");


?>   


    </div>
    <!-- ################################################################################################ -->
  </div>
  <!-- ################################################################################################ -->
</div>







<div class="wrapper row4 bgded overlay" style="background-image:url('images/demo/backgrounds/02.png');">
  <footer id="footer" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="one_third first">
      <h3 class="heading">Yosemite Automotriz</h3>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-vk" href="#"><i class="fa fa-vk"></i></a></li>
      </ul>
    </div>
    <div class="one_third">
      <ul class="nospace meta">
        <li class="btmspace-15"><i class="fa fa-phone"></i>   55-6752-7532 Ext.1248</li>
        <li><i class="fa fa-envelope-o"></i> contacto@YosemiteAutomotriz.com</li>
      </ul>
    </div>
    <div class="one_third">
      <form method="post" action="#">
        <fieldset>
       
        </fieldset>
      </form>
    </div>
    <!-- ################################################################################################ -->
  </footer>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2016 - All Rights Reserved - <a href="#">Domain Name</a></p>
    <p class="fl_right"> <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates"></a></p>
    <!-- ################################################################################################ -->
  </div>
</div>
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>



          <script>
function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
     <script>
function solonumeros(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }


    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>
    <script>
function solonumerosyletras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " 0123456789áéíóúabcdefghijklmnñopqrstuvwxyz,:;¿?#()";
    especiales = [8, 37, 39, 46];

    tecla_especial = false
    for(var i in especiales) {
        if(key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if(letras.indexOf(tecla) == -1 && !tecla_especial)
        return false;
}

function limpia() {
    var val = document.getElementById("miInput").value;
    var tam = val.length;
    for(i = 0; i < tam; i++) {
        if(!isNaN(val[i]))
            document.getElementById("miInput").value = '';
    }
}
</script>  



<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.flexslider-min.js"></script>
</body>
</html>